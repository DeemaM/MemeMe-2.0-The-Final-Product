//
//  File.swift
//  Meme1.0
//
//  Created by Deema  on 13/04/2019.
//  Copyright © 2019 Udacity. All rights reserved.
//

import UIKit

struct Meme {
    let topTextField: String!
    let bottomTextField: String!
    let originalImage: UIImage!
    let memedImage: UIImage!
}
